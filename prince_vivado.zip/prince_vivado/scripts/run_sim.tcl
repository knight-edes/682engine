# Behavioural simulation of tb_prince in xsim (project mode).
# Usage:  vivado -mode batch -source scripts/run_sim.tcl
#    or, with the project open in the GUI:  source scripts/run_sim.tcl
set root [file normalize [file join [file dirname [info script]] ..]]
if {[catch {current_project}]} {
    open_project [file join $root vivado_proj prince_zed.xpr]
}
launch_simulation -simset sim_1 -mode behavioral
run all
close_sim
