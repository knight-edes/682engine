# Timing-only constraints for out-of-context (OOC) synthesis of prince_top.
# No pin locations: this measures the block itself, not a board top level.
create_clock -period 10.000 -name clk [get_ports clk]          ;# 100 MHz target
set_input_delay  -clock clk 0.000 [get_ports -filter {DIRECTION == IN && NAME != clk}]
set_output_delay -clock clk 0.000 [get_ports -filter {DIRECTION == OUT}]
